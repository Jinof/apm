package com.jinof.apm.bench;

import android.graphics.Rect;
import android.os.SystemClock;
import com.android.uiautomator.core.Configurator;
import com.android.uiautomator.core.UiDevice;
import com.android.uiautomator.core.UiObject;
import com.android.uiautomator.core.UiSelector;
import com.android.uiautomator.testrunner.UiAutomatorTestCase;

public final class HeatmapReady extends UiAutomatorTestCase {
    public void testCalendar() throws Exception {
        Configurator.getInstance().setWaitForIdleTimeout(0).setWaitForSelectorTimeout(0);
        UiDevice device = getUiDevice();
        UiObject tab = new UiObject(new UiSelector().description("年度热力图"));
        assertTrue("Expected album before timing", new UiObject(new UiSelector().description("平滑横向分页，当前相册页面")).exists());
        Rect hit = tab.getBounds();
        UiObject page = new UiObject(new UiSelector().descriptionStartsWith("热力图页面，左右"));
        UiObject first = new UiObject(new UiSelector().descriptionContains("年1月1日，"));
        UiObject last = new UiObject(new UiSelector().descriptionContains("年12月31日，"));
        UiObject dated = new UiObject(new UiSelector().descriptionContains("张照片，热度").clickable(true));
        int width = device.getDisplayWidth();
        long started = SystemClock.elapsedRealtime();
        assertTrue(device.click(hit.centerX(), hit.centerY()));
        while (SystemClock.elapsedRealtime() - started < 8000) {
            if (page.exists() && page.getBounds().width() >= width - 1 && first.exists() && last.exists() && dated.exists()) {
                long elapsed = SystemClock.elapsedRealtime() - started;
                assertTrue(dated.click());
                assertTrue("Day responds to a tap", new UiObject(new UiSelector().textStartsWith("已选 ")).waitForExists(5000));
                System.out.println("APM_CALENDAR_READY_MS=" + elapsed);
                android.os.Bundle result = new android.os.Bundle();
                result.putString("APM_CALENDAR_READY_MS", String.valueOf(elapsed));
                getAutomationSupport().sendStatus(0, result);
                return;
            }
            SystemClock.sleep(12);
        }
        fail("Full year with a selectable date did not become ready");
    }
}
